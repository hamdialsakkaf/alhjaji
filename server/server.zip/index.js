const express = require("express")
const db = require('./config/db')
const dotenv = require("dotenv")
//dotenv.config()
// from vedio
const config = require("./config/db")
const { port, allowedDomains }  = config
const cors = require('cors')
const bcrypt = require('bcrypt');

const app = express()
//const PORT = 3002;
// from vedio
app.use(cors({origin: allowedDomains, credentials: true }))
//app.use(helmet())
app.use(express.json())
//app.use(cors({ origin: 'https://alhjaji.com/', credentials: true }));
//app.use(cors({ origin: process.env.REMOTE_CLIENT_APP, credentials: true }));
app.use(cors({
    origin: '*' , 
    methods: 'GET,PUT,POST,OPTIONS', 
   'Access-Control-Allow-Origin': '*'
}));

   app.use(cors({
    origin: '*'
}));
/*
app.use(cors({
   // origin: 'https://alhjaji.com/',
    origin: ['https://alhjaji.com', 'http://alhjaji.com/']
}));
*/
const whitelist = ['https://alhjaji.com', 'http://alhjaji.com']
const corsOptions = {
  origin: (origin, callback) => {
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error())
    }
  }
}


 
// Middleware Function to authenticate the user
const auth = (req, res, next) => {
    console.log(req.body);
    if(req.body.logged){
        next();
        return;
    }
    res.send({
        success: false,
        message: "Unauthorized Access"
    });
}

// Post request handler for the /admin route
app.post("/admin", auth, (req, res) => {
    res.send({
        success: true,
        message: "Successfully Authenticated"
    });
})

// Route to get all posts
app.get("/api/get", cors(), (req, res) => {
    //res.set({ "Access-Control-Allow-Origin": "*" });
    //res.header("Access-Control-Allow-Origin", "true");

      res.set({ 
            'Cache-Control': 'no-cache', 
            'Access-Control-Allow-Origin': "*"
        }); 
        
    db.query("SELECT * FROM posts", (err, result) => {
        if(err) {
            console.log(err)
        }

    res.send(result)
    })
});

// Route to get all tires
app.get("/api/getire", cors(),(req, res) => {
     res.set({ 
            'Cache-Control': 'no-cache', 
            'Access-Control-Allow-Origin': "*"
        }); 
    db.query("SELECT * FROM tires LIMIT 4", (err, result) => {
        if(err) {
            console.log(err)
        }
       // console.log('result tires',result)

    res.send(result)
    })
});

// Route to get one post
app.get("/server/getFromId/:id", cors(), (req,res)=>{
     res.set({ 
            'Cache-Control': 'no-cache', 
            'Access-Control-Allow-Origin': "*"
        }); 
    const id = req.params.id;
    db.query("SELECT * FROM posts WHERE id = ?", id,
    (err, result) => {
        if(err) {
            console.log(err)
        }
        res.send(result)
    })
});

// Route to get one tire
app.get("/api/getFromTireId/:id", cors(), (req,res)=>{
     res.set({ 
            'Cache-Control': 'no-cache', 
            'Access-Control-Allow-Origin': "*"
        }); 
    const id = req.params.id;
    db.query("SELECT * FROM tires WHERE id = ?", id,
    (err, result) => {
        if(err) {
            console.log(err)
        }
        res.send(result)
    })
});
// Route to get one tire
app.get("/api/getFromTireSize/:tiresize",cors(), (req,res)=>{
     res.set({ 
            'Cache-Control': 'no-cache', 
            'Access-Control-Allow-Origin': "*"
        }); 
    const tiresize = req.params.tiresize;
   db.query("SELECT * FROM tires WHERE TireSize = ?", tiresize,
   // db.query("SELECT * FROM tires WHERE TireSize = ?", tiresize,
    (err, result) => {
        if(err) {
            console.log(err)
        }
   
        res.send(result)

        console.log('Tires on Size:', result)
    })
})
// Route to get Dolar Yemeni
app.get("/api/getexchangeDolar",cors(), (req,res)=>{
   db.query("SELECT DolarexchangeRial FROM exchange",
   // db.query("SELECT * FROM tires WHERE TireSize = ?", tiresize,
    (err, result) => {
        if(err) {
            console.log(err)
        }
       // console.log('result:',result[0].DolarexchangeRial)

        res.send(result)

    })
})

// Route to get brand logo
app.get("/api/getBrandLogo/:BrandName", cors(),(req,res)=>{
    const BrandName = req.params.BrandName;
   db.query("SELECT * FROM brands WHERE BrandName= ?", BrandName,
   // db.query("SELECT * FROM tires WHERE TireSize = ?", tiresize,
    (err, resultLogo) => {
        if(err) {
            console.log(err)
        }
        console.log('BrandName:', resultLogo[0])

        res.send(resultLogo)

    })
})


// Route for creating the post
app.post('/api/create', cors(),(req, res) => {
    const username = req.body.userName;
    const title = req.body.title;
    const text = req.body.text;
    db.query("INSERT INTO posts (title, post_text, userName) VALUES (?,?,?)",[title,text,username], (err, result)=>{
        if(err){
            console.log(err)
        }
        console.log(result)
    })
});

// Route for creating the tire
app.post('/api/createtire', cors(), (req, res) => {
    const brandname = req.body.brandname;
    const tiresize = req.body.tiresize;
    const image = req.body.imageurl;
    const Maxload = req.body.Maxload;
    const MaxSpeed = req.body.MaxSpeed;
    const Depthoftread = req.body.Depthoftread;
    const Rollingresistance = req.body.Rollingresistance;
    const Wetgripclass = req.body.Wetgripclass;
    const noiseClass = req.body.noiseClass;

    const price = req.body.price;

    db.query("INSERT INTO tires (brandname, tiresize, image,Maxload,MaxSpeed,Depthoftread,Rollingresistance,Wetgripclass,noiseClass, price) VALUES (?,?,?,?,?,?,?,?,?,?)",[brandname,tiresize,image,Maxload,MaxSpeed,Depthoftread,Rollingresistance,Wetgripclass,noiseClass,price], (err, result)=>{
        if(err){
            console.log(err)
        }
        console.log(result)
    })
});

// Route to like a post
app.post('/api/like/:id',cors(),(req,res)=>{
    const id = req.params.id;
    db.query("UPDATE posts SET likes = likes + 1 WHERE id = ?",id, (err,result)=>{
        if(err) {
       console.log(err)   } 
       console.log(result)
        });    
    });

    // Route to delete a post
    app.delete('/api/delete/:id',cors(), (req,res)=>{
    const id = req.params.id;
    
    db.query("DELETE FROM posts WHERE id= ?", id, (err,result)=>{
    if(err) {
    console.log(err)
            } 
        })
    });

      // Route to delete a post
      app.delete('/api/deleteTire/:id',cors(),(req,res)=>{
        const id = req.params.id;
        
        db.query("DELETE FROM tires WHERE id= ?", id, (err,result)=>{
        if(err) {
        console.log(err)
                } 
            })
        });


        // Route for creating User
app.post('/users',cors(), (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const password = req.body.password;
    db.query("INSERT INTO users (name, email, password) VALUES (?,?,?)",[name,email,password], (err, result)=>{
        if(err){
            console.log(err)
        }
        console.log(result)
    })
});

// Route to login Users
//app.get("/login/:params", (req,res)=>{


    app.post('/login/',cors(), async (req, res) => {

            const email = req.body.email;
            const passowrd = String(req.body.passowrd);
            console.log('email', email)
            console.log('passowrd:',passowrd)
            //db.query("SELECT * FROM users WHERE email= ? AND password= ? ",[email ,passowrd] ,

            // db.query("SELECT * FROM tires WHERE TireSize = ?", tiresize,
            db.query("SELECT * FROM users WHERE email= ?",email,

            (err, result) => {
                if(err) {
                   console.log('err',err)

                }
                res.send(result)
               // const passowrdHash =String(result[0].password)
                //  console.log('passowrdHash:',passowrdHash)
                /*
              bcrypt.compare(passowrd,passowrdHash).then((rese)=>{
                console.log('match:', rese)
                if(rese){
                    res.send(result)
                }
                console.log('errlogin:')

             })
             */
          //const match2= checkUser(passowrd,passowrdHash)
/*
            if(match) {
                //login
                 console.log('login match')
                  res.send(result)
            } else {
                //return res.redirect('/')
                //res.json('errlogin')
                console.log('errlogin:',err)
            }
            */
        })
      
    })
    
   
/*
       if (email ) {
        console.log(email+'='+ emailAuth)
    }
    if (passowrd ) {
        console.log(passowrd+'='+ passowrdAuth)
        res.send(result)
    } else {
        res.send(err)
    }
    */
    //})
       
    
  /*
    let myPromise = new Promise(function(myResolve, myReject) {
        let x = 0;
      
      // some code (try to change x to 5)
      if (email = emailAuth) {
        myResolve("OK");
      } else {
          myReject("Error");
        }
      });
      
      myPromise.then(
        function(value) {
            if (passowrd = passowrdAuth) {
                res.send(reault)
            }
            myDisplayer(value);
        },
        function(error) {myDisplayer(error);}
      );
  */
//})


    app.listen(port,()=> {
        console.log('listining')
    })

    //app.listen()